# MotivateMe

Motivational quote generator. This is fun little project intended to make people smile but also, wanted to build a small project so I can test out publishing this as a package on GitHub. 

Motivational quotes were downloaded from this website: https://sharpquotes.com/download-45500-famous-motivational-quotes-database-in-excel-and-pdf/#:~:text=Download%2045500%20Famous%20Motivational%20Quotes%20Database%20in%20Excel,class%20is%20running%20the%20country.%20...%20More%20items

I downloaded the excel file and converted that data into a JSON file.